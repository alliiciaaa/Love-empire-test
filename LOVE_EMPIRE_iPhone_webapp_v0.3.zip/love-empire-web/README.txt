LOVE EMPIRE — PRIVATE WEBAPP v0.3

Dit is een statische webapp die op iPhone (Safari) en Android (Chrome) werkt zodra hij via HTTPS wordt gehost.

ZONDER COMPUTER PUBLICEREN VIA GITHUB (handmatig):
1. Maak een GitHub-account aan of log in via Safari op github.com.
2. Maak een nieuwe PUBLIC repository, bijvoorbeeld love-empire-private-test.
3. Upload index.html en manifest.webmanifest naar de hoofdmap (via Add file > Upload files; eventueel desktopweergave in Safari).
4. Open Settings > Pages > Build and deployment en kies Deploy from a branch, branch main, folder / (root). Sla op.
5. Wacht tot GitHub Pages de HTTPS-link toont en open die in Safari.
6. Kies Deel > Zet op beginscherm.

LET OP PRIVACY: GitHub Pages op een publieke repository is openbaar voor iedereen met de URL. Gebruik geen persoonlijke of expliciete eigen opdrachten in de repository. Zelf toegevoegde kaarten worden lokaal in de browser opgeslagen, niet in de repository. Deel de link niet als je de app echt privé wilt houden. De app is niet met een wachtwoord beveiligd.

Alternatief: host de twee bestanden via een eigen privé hostingoplossing met toegangscontrole.

Dit is een prototype en nog geen App Store/Play Store publicatie. Voor later commercieel gebruik zijn verdere tests, contentreview, privacybeleid en distributie-inrichting nodig.
